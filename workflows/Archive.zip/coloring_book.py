# /// script
# dependencies = []
#
# [tool.griptape-nodes]
# name = "coloring book"
# schema_version = "0.1.0"
# engine_version_created_with = "0.3.2"
# node_libraries_referenced = [
#     [
#       "Griptape Nodes Library",
#       "0.1.0"
#     ]
#   ]
#
# ///
